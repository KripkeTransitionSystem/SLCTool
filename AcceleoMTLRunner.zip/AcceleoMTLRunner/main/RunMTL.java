package AcceleoMTLRunner.main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.SoftBevelBorder;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.resource.XtextResourceSet;
import  org.xtext.example.mandsl.ManDslStandaloneSetup;

import com.google.inject.Injector;

import cs.ualberta.launcher.Launcher;

public class RunMTL {
	static int selected;
	static String selectactor,selectG1,selectG2,selectop1,selectop2;
	 static  JLabel Properties = new JLabel("List Of Property");
	  static  JLabel actors2 = new JLabel("Select Any Actor");
	  static  JLabel prop= new JLabel("Select Any property");
	  static  JLabel lb1= new JLabel("Dependee Goal");
	  static  JLabel lb2= new JLabel("Depender Goal");
	  static JComboBox actorlist=new JComboBox();
	  static JComboBox property=new JComboBox();
	  static JComboBox J,G1,G2,O1,O2,A1,A2,O3,Go1,Go2;
	static final JButton edit= new JButton("Edit Property");
	static final JButton gtgoal= new JButton("Get Goals");
	static final JButton getprop= new JButton("Get Property");
	static final JButton delete = new JButton("Delete Property");
	static String tempex;
	static int ctltypeflag;
	static int duraSIA=0;
	static int duramSIA=0;
	static JFrame frame1;
	static JFrame frameFirst;
	static final JButton submit1 = new JButton("Set Property"); 
	static final JButton submit2 = new JButton("Set Property"); 
	 static JTextArea textAreaF = new JTextArea(600,600);
	 static JScrollPane scrollPane5 = new JScrollPane(textAreaF); 
	  static  JLabel labelF1 = new JLabel("Temporal Ordering of Events");
	  static  JLabel labelF2 = new JLabel("Inter-actor Dependency");
	  static  JLabel actors = new JLabel("Select an actor");
	  static  JLabel Goal1 = new JLabel("Select Dependee Goal");
	  static  JLabel Goal2 = new JLabel("Select Depender Goal");
	  static  JLabel op1 = new JLabel("Select Path operator");
	  static  JLabel op2 = new JLabel("Select ordering operator");
	  static  JLabel Actor1 = new JLabel("Select Dependee Actor");
	  static  JLabel op3 = new JLabel("Select an operator");
	  static  JLabel Actor2 = new JLabel("Select Depender Actor");
	  static final JButton back = new JButton("RESTART");
		static final JButton save = new JButton("Save");
		static final JButton save2 = new JButton("Save");
	static final JButton save_button=new JButton("Save Metrics");
	static final JButton input_file_button = new JButton("Choose Input File"); 
	static final JButton generateFSM = new JButton("Generate FSM"); 
	static final JButton output_file_button = new JButton("Check FSM(SIA)"); 
	static final JButton output_file_button2 = new JButton("Check FSM(M-SIA)"); 
	static final JButton checkNuSMV_button = new JButton("Check NuSMV Input(SIA)"); 
	static final JButton checkNuSMV_button2 = new JButton("Check NuSMV Input(M-SIA)"); 
	static final JButton validate_button = new JButton("Validate Transition Model(SIA)"); 
	static final JButton validate_button2 = new JButton("Validate State Transition Model(M-SIA)"); 
	static final JButton clean_up = new JButton("Clean Up"); 
	   static JTextArea textArea = new JTextArea(600,600);	
	   static JScrollPane scrollPane = new JScrollPane(textArea); 
	   static JTextArea textCTL= new JTextArea(300,300);
	   static JScrollPane scrollPane2 = new JScrollPane(textCTL); 
	   static JTextArea textArea2 = new JTextArea(500,500);	
	   static JTextArea textArea3 = new JTextArea(300,300);	
	   static JScrollPane scrollPane3 = new JScrollPane(textArea2); 
	   static JScrollPane scrollPane4 = new JScrollPane(textArea3); 
	  static  JLabel label1 = new JLabel("CTL in Existential Form");
	  static JTextField texttransitions= new JTextField();
	  static JTextField texttransitions2= new JTextField();
	 static  JLabel label2 = new JLabel("# transitions");
	 static JTextField textpaths= new JTextField();
	 static JTextField textpaths2= new JTextField();
	 static JTextField reduceTransition= new JTextField();
	 static JTextField reducePaths= new JTextField();
	 static  JLabel label3 = new JLabel("# Execution Paths");
	 static  JLabel label4 = new JLabel("OUTPUT PANEL");
	 static  JLabel label5 = new JLabel("Compliant FSM");
	 static  JLabel label6 = new JLabel("INPUT PANEL");
	 static  JLabel label7 = new JLabel("Button Panel");
	 static  JLabel label8 = new JLabel("i* Goal Model using XtGRL with CTL properties");
	 static JLabel label9 = new JLabel("Validation Result ");
	 static  JLabel label10 = new JLabel("SIA ");
	 static JLabel label11 = new JLabel("M-SIA");
	 static JLabel label12 = new JLabel("Execution Time(ms)");
	 static JLabel label13=new JLabel("# Nodes");
	 static JLabel label14=new JLabel("Decomposition Type");
	 static JLabel label15=new JLabel("AND");
	 static JLabel label16=new JLabel("OR");
	 static JLabel label17=new JLabel("Number");
	 static JLabel label18=new JLabel("Child");
	 static JLabel label19=new JLabel("% reduction");
	 static JLabel label20=new JLabel("Metrics");
	 static JTextField textTime= new JTextField();
	 static JTextField textTime2= new JTextField();
	 static JTextField andnum= new JTextField();
	 static JTextField andchild= new JTextField();
	 static JTextField ornum= new JTextField();
	 static JTextField orchild= new JTextField();
	 static JTextField nodes=new JTextField();
	static Node head=null;
	static int type=0;
	static int generate_flag;
	static String[][] ctlList= new String[1000][3];
	static String[][] ctlListfinal= new String[1000][5];
	static String[][] dependencylist=new String[1000][2];
	static String[][] dependencylist2=new String[1000][2];
	static int dlist=0,dlist2=0;
	static int ctlrow=0;
	static String depender=null;
	static String dependee=null;
	static variable start=null;
	static parentPath phead=null;
	static list lhead=null;
	static int a[]=new int[25000];
	static int noOfTerms;
	static int permute[][]=new int[30000][1000];
	static int row=0,column=0,valid=0;
	static int execCount=1;
	static int nodeCount=0;
	//static FileOutputStream fpermute=null;
	//static BufferedWriter fpwrite=null;
	static int flag1=0,flag2=0,flag3=0,flag4=0,flag5=0,flag6=0,check=0;
	static int count1=0;
	static int transitions=0;
	static int transitionsSIA=0;
	static int transitionsmSIA=0;
	static String existential=null;
	static int typepath[]= new int[1000];
	static int tp=0;
	static int cp=0;
	static int pathtemp=0;
	static int pathSIA=0;
	static int SIA=0;
	static int actcount=0;
	static String filename=null;
	static long startTime;
	static int ctlflag=0;
	static String actor;
	static String[] actorList;
	static int actorListIndex=0;
	static int andnum1=0;
	static int andchild1=0;
	static int ornum1=0;
	static int orchild1=0;
	static int totalNodes=0;
	static int flagactor=0;
	static int working=0;
	static String selected_file="";
	static String deleted="";
	public static void delete_files()
	{
        File file = new File("c:\\\\CompliantFSM\\\\stt.ndsl");

        if(file.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        int i=1;
       int  flag=1;
        while(flag==1)
        {
        	String name="c:\\\\CompliantFSM\\\\VAR"+i+".txt";
        	  file=new File(name);
        	  if(file.delete()){
                //  System.out.println("Cleared2");
              }else flag=0;
        	  i++;
        }
        file = new File("c:\\\\CompliantFSM\\\\NUSMV_input.smv");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\sttSIA.txt");
        file.delete();
    	file=new File("c:\\\\CompliantFSM\\\\actors.txt");
		file.delete();
    	file=new File("c:\\\\CompliantFSM\\\\InterActorCTL.txt");
		file.delete();
        file = new File("c:\\\\CompliantFSM\\\\NUSMV_inputSIA.smv");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\sttSIA.ndsl");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\Temp.smv");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\pstt.ndsl");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\NUSMV_input.smv");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\output.txt");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\existential.txt");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\temp_input.ndsl");
        file.delete();
        file = new File("c:\\\\CompliantFSM\\\\temp_input2.ndsl");
        file.delete();
        System.out.println("Files Deleted");
      	}
	
	public static void delete_files2() {
		File file;
		  FileReader f1=null;
	        try {
	        	f1=new FileReader("c:\\\\CompliantFSM\\\\actors.txt");
	        	int i;
	        	char c;
	        	String temp="";
	        	System.out.println("Hiee");
	        	while((i=f1.read())!=-1)
	        	{
	        		temp="c:\\\\CompliantFSM\\\\";
	        		c=(char)i;
	        		temp=temp.concat(Character.toString(c));
	        		while((i=f1.read())!=10){
	        			c=(char)i;
	        		if((i>=65 && i<=90) ||(i>=97 && i<=122) || i==95)
	        			temp=temp.concat(Character.toString(c));
	        		}
	        		temp=temp.concat("CTL.txt");
	        		System.out.println("temp is"+temp);
	        		file=new File(temp);
	        		file.delete();
	        	}
	        	
	        }
	        catch(IOException ioe) {
	        	System.out.println("not found");
	        }
	    

	}
	public static void create_repository() {
		int flag=0;
		File reposit=new File("c:\\\\CompliantFSM\\\\CTLrepository.txt");
		if(reposit.exists()) {
			FileReader f1=null;
			try {
			FileReader actor=new FileReader("c:\\\\CompliantFSM\\\\actors.txt");
			int i;
			char c;
			while((i=actor.read())!=-1) 
			{
				String temp="";
				c=(char)i;
				temp=temp.concat(Character.toString(c));
				while((i=actor.read())!=10) {
							c=(char)i;
				temp=temp.concat(Character.toString(c));
				}
				FileReader ctl=new FileReader("c:\\\\CompliantFSM\\\\"+temp+"CTL.txt");
				flag=0;
				while((i=ctl.read())!=-1) 
				{
					String temp2="";
					c=(char)i;
					temp2=temp2.concat(Character.toString(c));
					while((i=ctl.read())!=10) {
								c=(char)i;
					temp2=temp2.concat(Character.toString(c));
					}
					f1=new FileReader("c:\\\\CompliantFSM\\\\CTLRepository.txt");
					flag=0;
					while((i=f1.read())!=-1) 
					{
						String temp3="";
						c=(char)i;
						temp3=temp3.concat(Character.toString(c));
						while((i=f1.read())!=10) {
									c=(char)i;
						temp3=temp3.concat(Character.toString(c));
						}
						if(temp3.compareTo(temp2)==0)
							flag=1;
					}
					f1.close();
					if(flag==0) {
					BufferedWriter b1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\CTLRepository.txt",true));
					b1.write(temp2);
					b1.newLine();
					b1.close();
					}
					
				}
				ctl.close();
			}
			actor.close();
			}
			catch(IOException e) {
				
			}
			
		}
		else {
			System.out.println("Executing else");
			FileReader f1=null;
			try {
			FileReader actor=new FileReader("c:\\\\CompliantFSM\\\\actors.txt");
			int i;
			char c;
			while((i=actor.read())!=-1) 
			{
				String temp="c:\\\\CompliantFSM\\\\";
				c=(char)i;
				temp=temp.concat(Character.toString(c));
				while((i=actor.read())!=10) {
							c=(char)i;
				temp=temp.concat(Character.toString(c));
				}
				System.out.println("temp is"+temp);
				temp=temp.concat("CTL.txt");
				FileReader ctl=new FileReader(temp);
				System.out.println("ctl is"+ctl);
				flag=0;
				while((i=ctl.read())!=-1) 
				{
					String temp2="";
					c=(char)i;
					temp2=temp2.concat(Character.toString(c));
					while((i=ctl.read())!=10) {
								c=(char)i;
					temp2=temp2.concat(Character.toString(c));
					}
					System.out.println("temp2 is"+temp2);
					BufferedWriter b1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\CTLRepository.txt",true));
					b1.write(temp2);
					b1.newLine();
					b1.close();
					}
					
				ctl.close();
			}
			actor.close();
			}
			catch(IOException e) {
				
			}
		}
	}
	public static void create_firstFrame() {
	
		frameFirst.getContentPane().setBackground(new Color(144,238,144));
		working=0;
		selectactor=null;
		selectG1=null;
		selectG2=null;
		selectop1=null;
		selectop2=null;
		 flagactor=0;
		 String[] temp1= {"","AG","EF"};
		 String[] temp2= {"","AF","AX","EX","EF"};
		 String[] temp3= {"","AF","AX"};
		JButton close=new JButton("Submit");
		JButton getGoals=new JButton("Get Goals");
		
		J=new JComboBox();
		G1=new JComboBox();
		G2=new JComboBox();
		Go1=new JComboBox();
		Go2=new JComboBox();
		A1=new JComboBox();
		A2=new JComboBox();
		O3=new JComboBox(temp3);
		O1=new JComboBox(temp1);
		O2=new JComboBox(temp2);
	
		String[] actor=new String[actcount+1];
		int index=1;
		
		textAreaF.setFont(new Font("Calibri", Font.ITALIC, 16));
		labelF1.setFont(new Font("Calibri", Font.ITALIC, 16));
		labelF2.setFont(new Font("Calibri", Font.ITALIC, 16));
		actors2.setFont(new Font("Calibri", Font.ITALIC, 16));
		prop.setFont(new Font("Calibri", Font.ITALIC, 16));
		  submit1.setFont(new Font("Calibri", Font.ITALIC, 16));
		   submit1.setBackground(new Color(72,209,204));
		   submit1.setForeground(Color.black);
		   submit2.setFont(new Font("Calibri", Font.ITALIC, 16));
		   submit2.setBackground(new Color(72,209,204));
		   submit2.setForeground(Color.black);
		   edit.setFont(new Font("Calibri", Font.ITALIC, 16));
		   edit.setBackground(new Color(72,209,204));
		   edit.setForeground(Color.black);
		   delete.setFont(new Font("Calibri", Font.ITALIC, 16));
		   delete.setBackground(new Color(72,209,204));
		   delete.setForeground(Color.black);
		   getprop.setFont(new Font("Calibri", Font.ITALIC, 16));
		   getprop.setBackground(new Color(72,209,204));
		   getprop.setForeground(Color.black);
		   input_file_button.setFont(new Font("Calibri", Font.ITALIC, 16));
	        input_file_button.setBackground(new Color(72,209,204));
	        input_file_button.setForeground(Color.black);
	        input_file_button.setBounds(15, 40, 250, 40);
	        clean_up.setBackground(new Color(72,209,204));
	        clean_up.setForeground(Color.black);
	        clean_up.setBounds(290, 40, 250, 40);
	        frameFirst.add(clean_up);
	 	  save.setFont(new Font("Calibri", Font.ITALIC, 16));
	        save.setBackground(new Color(72,209,204));
	        save.setForeground(Color.black);
	     
	      
	        
		textAreaF.setEditable(false);
	
		 try { 
			  
	          
	        	UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
	        } 
	        catch (Exception e) { 
	            System.out.println("Look and Feel not set"); 
	        } 
	  frameFirst.setLayout(null);
	  frameFirst.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	  frameFirst.setBounds(15, 6, 2000, 900);
	  
	  frameFirst.add(input_file_button);
	  Properties.setFont(new Font("Calibri", Font.ITALIC, 16));
	   close.setFont(new Font("Calibri", Font.ITALIC, 16));
	   getGoals.setFont(new Font("Calibri", Font.ITALIC, 16));
	   actors.setFont(new Font("Calibri", Font.ITALIC, 16));
	   Goal1.setFont(new Font("Calibri", Font.ITALIC, 16));
	   Goal2.setFont(new Font("Calibri", Font.ITALIC, 16));
	   lb1.setFont(new Font("Calibri", Font.ITALIC, 16));
	   lb2.setFont(new Font("Calibri", Font.ITALIC, 16));
	   op1.setFont(new Font("Calibri", Font.ITALIC, 16));
	   op2.setFont(new Font("Calibri", Font.ITALIC, 16));
	  Actor1.setFont(new Font("Calibri", Font.ITALIC, 16));
	   Actor2.setFont(new Font("Calibri", Font.ITALIC, 16));
	   op3.setFont(new Font("Calibri", Font.ITALIC, 16));
	   close.setBackground(new Color(72,209,204));
	   close.setForeground(Color.black);
	   close.setBounds(150, 700, 150, 40);
	  gtgoal.setBackground(new Color(72,209,204));
	   gtgoal.setForeground(Color.black);
	   gtgoal.setBounds(150, 700, 150, 40);
	   getGoals.setBackground(new Color(72,209,204));
	   getGoals.setForeground(Color.black);
	   getGoals.setBounds(1080, 130, 150, 40);
	   scrollPane5.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	   scrollPane5.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	   scrollPane5.setBounds(15, 90, 700, 500); 
	   frameFirst.add(scrollPane5);
	   labelF1.setBounds(800, 50, 250, 40);
	   frameFirst.add(labelF1);
	   Properties.setBounds(1400, 70, 250, 40);
	   frameFirst.add(Properties);
	   actors2.setBounds(1400, 120, 250, 40);
	   frameFirst.add(actors2);
	   prop.setBounds(1400, 190, 250, 40);
	   frameFirst.add(prop);
	   actorlist.setBounds(1550, 120, 150, 40);
	   frameFirst.add(actorlist);
	   property.setBounds(1400, 250, 400, 40);
	   frameFirst.add(property);
	   getprop.setBounds(1740, 120, 140, 40);
	   frameFirst.add(getprop);
	   edit.setBounds(1400, 330, 140, 40);
	   frameFirst.add(edit);
	   delete.setBounds(1600, 330, 140, 40);
	   frameFirst.add(delete);
	   actors.setBounds(800, 90, 250, 40);
	   frameFirst.add(actors);
	   frameFirst.add(getGoals);
	   J.setBounds(800,130,250,40);
	   frameFirst.add(J);
	   op1.setBounds(800, 190, 250, 40);
	   frameFirst.add(op1);
	   O1.setBounds(800, 240, 250, 40);
	   frameFirst.add(O1);
	   op2.setBounds(1090, 190, 250, 40);
	   frameFirst.add(op2);
	   O2.setBounds(1090, 240, 250, 40);
	   frameFirst.add(O2);
	   Goal1.setBounds(800, 300, 250, 40);
	   frameFirst.add(Goal1);
	   G1.setBounds(800,350,250,40);
	   frameFirst.add(G1);
	  Goal2.setBounds(1090, 300, 250, 40);
	   frameFirst.add(Goal2);
	   G2.setBounds(1090,350,250,40);
	   frameFirst.add(G2);
	   labelF2.setBounds(800, 500, 250, 40);
	   frameFirst.add(labelF2);
	   Actor1.setBounds(800, 530, 250, 40);
	   frameFirst.add(Actor1);
	   A1.setBounds(800,560,250,40);
	   frameFirst.add(A1);
	   Actor2.setBounds(1090, 530, 250, 40);
	   frameFirst.add(Actor2);
	   A2.setBounds(1090,560,250,40);
	   frameFirst.add(A2);
	   gtgoal.setBounds(1390,560,150,40);
	   frameFirst.add(gtgoal);
	   op3.setBounds(800,620,250,40);
	   frameFirst.add(op3);
	   O3.setBounds(970,620,250,40);
	   frameFirst.add(O3);
	   submit1.setBounds(800, 450, 150, 40);
	   frameFirst.add(submit1);
	   save.setBounds(400, 700, 150, 40);
	   frameFirst.add(save);
	   submit2.setBounds(800, 800, 150, 40);
	   frameFirst.add(submit2);
	   lb1.setBounds(800, 670, 150, 40);
	   frameFirst.add(lb1);
	   lb2.setBounds(1100, 670, 150, 40);
	   frameFirst.add(lb2);
	   Go1.setBounds(800, 720, 250, 40);
	   frameFirst.add(Go1);
	   Go2.setBounds(1100, 720, 250, 40);
	   frameFirst.add(Go2);
	     frameFirst.add(close);
	     frameFirst.setVisible(true);
	     System.out.println("Done upto here");
	     close.setToolTipText("Click to Generate FSM");
	     save.setToolTipText("Click to see the updated input");
	     submit1.setToolTipText("Store Temporal Property");
	     submit2.setToolTipText("Store Inter-actor Property");
	     edit.setToolTipText("Click to Edit property");
	     delete.setToolTipText("Click to Delete property");
	     getGoals.setToolTipText("Click to get goals of actor");
	     gtgoal.setToolTipText("Click to get goals of actors");
	     getprop.setToolTipText("Click to see the stored property");
	     input_file_button.setText("Click to Load Input");
	     close.setEnabled(false);
	     submit1.setEnabled(false);
	     submit2.setEnabled(false);
	     edit.setEnabled(false);
	     delete.setEnabled(false);
	     getGoals.setEnabled(false);
	     gtgoal.setEnabled(false);
	     getprop.setEnabled(false);
	     save.setEnabled(false);
	    clean_up.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){
	           
	            	start_operation();
	            }
	     });
	     close.addActionListener(new ActionListener(){  
				            public void actionPerformed(ActionEvent e){
				            	if(selected_file=="")
				            	{
				            		JOptionPane.showMessageDialog(frameFirst, "Select an input file");
				            	}
				            	else {
				            	generate_input();
				            	copy_input();
				            	create_repository();
				            working=1;
				           //frameFirst.setVisible(false);
				           // frame1.dispose();
				        	frame1=new JFrame("My application");
				    		setFSM_name("Next");
				         
				            	}
				     
				           
				            
				        }  
				        });
	     save.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){
	            	generate_input();
	            	ChooseButtonActionPerformednew(e);
	            	//copy_input();
	            	
	            
	        }  
	        });
	     input_file_button.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            	delete_files();
	            	 ChooseButtonActionPerformed(e);
	            		delete_files2();
	            		String temp;
	            		J.removeAllItems();
	            		J.addItem("");
	            		A1.removeAllItems();
	            		A1.addItem("");
	            		A2.removeAllItems();
	            		A2.addItem("");
	            		actorlist.removeAllItems();
	            		actorlist.addItem("");
	            		FileReader f1=null;
	            		try {
	            		f1=new FileReader("c:\\\\CompliantFSM\\\\actors.txt");
	            		int i;
	            		char c;
	            		while((i=f1.read())!=-1) // Loop to read the entire input file
	            		{
	            			c=(char)i;
	            			//System.out.println(c);
	            			//System.out.println(c+"int="+i);
	            			temp="";
	            			temp=temp.concat(Character.toString(c));
	            			while((i=f1.read())!=10) {
	            				c=(char)i;
	            				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95) {
	            				temp=temp.concat(Character.toString(c));
	            				}
	            			}
	            			System.out.println("Actor is"+temp);
	            			J.addItem(temp);
	            			A1.addItem(temp);
	            			A2.addItem(temp);
	            			actorlist.addItem(temp);
	            			
	            		
	            		}
	            		actorlist.addItem("InterActor");
	            		f1.close();
	            		}
	            		catch(IOException ep) {
	            			
	            		}
	            		 close.setEnabled(true);
		        	     submit1.setEnabled(true);
		        	     submit2.setEnabled(true);
		        	     edit.setEnabled(true);
		        	     delete.setEnabled(true);
		        	     getGoals.setEnabled(true);
		        	     gtgoal.setEnabled(true);
		        	     getprop.setEnabled(true);
		        	     save.setEnabled(true);
	            	
	        }  
	        });
	     getprop.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            
	           String a=actorlist.getSelectedItem().toString();
	           //JOptionPane.showMessageDialog(frameFirst, "Actor selected is "+a);
	           String fname="c:\\\\CompliantFSM\\\\"+a+"CTL.txt";
	          // fname=fname.concat("\0");
	           System.out.println(fname);
	           property.removeAllItems();
	           property.addItem("");
	    	 //  JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	           FileReader f1=null;
	           try {
	        	    f1=new FileReader(fname);
	        	   int i;
	        	   char c;
	        	   String temp=null;
	        	 
	        	  // System.out.println("hiee");
	        	   while((i=f1.read())!=-1) // Loop to read the entire input file
	        	   {
	   			c=(char)i;
	   			//System.out.println(c);
	   			//System.out.println(c+"int="+i);
	   			temp="";
	   			temp=temp.concat(Character.toString(c));
	   			while((i=f1.read())!=10) {
	   				c=(char)i;
	   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32 || i==61 || i==46){
	   				temp=temp.concat(Character.toString(c));
	   				}
	   			}
	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	   			property.addItem(temp);
	   		
	   		}
	   		f1.close();
	   		}
	   		catch(IOException e2) {
	   		   System.out.println("hello");	
	   		} 
	       
	          }
	          });
	     getGoals.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            
	           String a=J.getSelectedItem().toString();
	           //JOptionPane.showMessageDialog(frameFirst, "Actor selected is "+a);
	           String fname="c:\\\\CompliantFSM\\\\"+a+".txt";
	          // fname=fname.concat("\0");
	           System.out.println(fname);
	           G1.removeAllItems();
	           G2.removeAllItems();
	           G1.addItem("");
	           G2.addItem("");
	    	 //  JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	           FileReader f1=null;
	           try {
	        	    f1=new FileReader(fname);
	        	   int i;
	        	   char c;
	        	   String temp=null;
	        	   int count=1;
	        	  // System.out.println("hiee");
	        	   while((i=f1.read())!=-1) // Loop to read the entire input file
	        	   {
	   			c=(char)i;
	   			//System.out.println(c);
	   			//System.out.println(c+"int="+i);
	   			temp="";
	   			temp=temp.concat(Character.toString(c));
	   			while((i=f1.read())!=10) {
	   				c=(char)i;
	   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32){
	   				temp=temp.concat(Character.toString(c));
	   				}
	   			}
	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	   			char[] copy=temp.toCharArray();
	   			String s;
	   			s="";
	   			int j=0;
	   			while(copy[j]!=' ') {
	   				s=s.concat(Character.toString(copy[j]));
	   				j++;
	   			}
	   			s=s.concat("=FU");
	   			if(count>1) {
	   			G1.addItem(s);
	   			G2.addItem(s);
	   			}
	   			count++;
	   		
	   		}
	   		f1.close();
	   		}
	   		catch(IOException e2) {
	   		   System.out.println("hello");	
	   		} 
	       
	          }
	          });
	     gtgoal.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            
	           String a1=A1.getSelectedItem().toString();
	           String a2=A2.getSelectedItem().toString();
	           //JOptionPane.showMessageDialog(frameFirst, "Actor selected is "+a);
	           String fname="c:\\\\CompliantFSM\\\\"+a1+".txt";
	          // fname=fname.concat("\0");
	           System.out.println(fname);
	           Go1.removeAllItems();
	           Go2.removeAllItems();
	           Go1.addItem("");
	           Go2.addItem("");
	    	 //  JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	           FileReader f1=null;
	           try {
	        	    f1=new FileReader(fname);
	        	   int i;
	        	   char c;
	        	   String temp=null;
	        	 
	        	  // System.out.println("hiee");
	        	   while((i=f1.read())!=-1) // Loop to read the entire input file
	        	   {
	   			c=(char)i;
	   			//System.out.println(c);
	   			//System.out.println(c+"int="+i);
	   			temp="";
	   			temp=temp.concat(Character.toString(c));
	   			while((i=f1.read())!=10) {
	   				c=(char)i;
	   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32){
	   				temp=temp.concat(Character.toString(c));
	   				}
	   			}
	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	   			char[] copy=temp.toCharArray();
	   			String s,t;
	   			s="";
	   			t="";
	   			int len=copy.length;
	   			int j=0;
	   			while(copy[j]!=' ') {
	   				s=s.concat(Character.toString(copy[j]));
	   				j++;
	   			}
	   			j++;
	   			while(j<len) {
	   				t=t.concat(Character.toString(copy[j]));
	   				j++;
	   			}
	   			
	   			if(t.compareTo("none")!=0) {
	   			s=s.concat("=FU");
	   			Go1.addItem(s);
	   			}
	   			
	   			
	   		
	   		}
	   		f1.close();
	   		fname="c:\\\\CompliantFSM\\\\"+a2+".txt";
	   	  f1=new FileReader(fname);

   	 
   	  // System.out.println("hiee");
   	   while((i=f1.read())!=-1) // Loop to read the entire input file
   	   {
			c=(char)i;
			//System.out.println(c);
			//System.out.println(c+"int="+i);
			temp="";
			temp=temp.concat(Character.toString(c));
			while((i=f1.read())!=10) {
				c=(char)i;
				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32){
				temp=temp.concat(Character.toString(c));
				}
			}
			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
			char[] copy=temp.toCharArray();
   			String s,t;
   			s="";
   			t="";
   			int len=copy.length;
   			int j=0;
   			while(copy[j]!=' ') {
   				s=s.concat(Character.toString(copy[j]));
   				j++;
   			}
   			j++;
   			while(j<len) {
   				t=t.concat(Character.toString(copy[j]));
   				j++;
   			}
   			
   			if(t.compareTo("none")!=0) {
   			s=s.concat("=FU");
   			Go2.addItem(s);
   			}
		
			
		
		}
		f1.close();
		
	   		
	   		}
	   		catch(IOException e2) {
	   		   System.out.println("hello");	
	   		} 
	       
	          }
	          });

	     	submit1.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            String actor=J.getSelectedItem().toString();
	            String fname="c:\\\\CompliantFSM\\\\"+actor+"CTL.txt";
	            //JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	            String op1=O1.getSelectedItem().toString();
	            String op2=O2.getSelectedItem().toString();
	            String dependee=G1.getSelectedItem().toString();
	            String depender=G2.getSelectedItem().toString();
	            BufferedWriter f1=null;
	            if(deleted!="") {
	            try {
				FileReader f2=new FileReader(fname);
				f1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\temp.txt",false));
				int i;
				char c;
				String temp="";
				while((i=f2.read())!=-1) {
					temp="";
					c=(char)i;
					temp=temp.concat(Character.toString(c));
					while((i=f2.read())!=10)
					{
						if(i==-1)
							break;
						c=(char)i;
						if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32 || i==61  || i==46) {
						temp=temp.concat(Character.toString(c));
						}
					}
					if(temp.compareTo(deleted)!=0 && i!=-1) {
						System.out.println("temp= "+temp);
						System.out.println("prop is= "+deleted);
						f1.write(temp);
						f1.newLine();
					}
				}
				
				f1.close();
				f2.close();
				f2=new FileReader("c:\\\\CompliantFSM\\\\temp.txt");
				f1=new BufferedWriter(new FileWriter(fname,false));
				while((i=f2.read())!=-1)
				{
					c=(char)i;
					f1.write(c);
				}
				f1.close();
				f2.close();
				}
				catch(IOException ioe) {
					
					ioe.printStackTrace();
					
				}	
	            deleted="";
	           }
	            if(dependee.compareTo(depender)==0 || dependee=="" || depender=="" || op1=="" || op2=="") {
	            	JOptionPane.showMessageDialog(frameFirst, "Invalid property..");
	            }
	            else if(op1=="AG" && (op2=="EF" || op2=="EX"))
	            {
	            	JOptionPane.showMessageDialog(frameFirst, "Invalid property..");
	            }
	            else if(op1=="EF" && (op2=="AF" || op2=="AX"))
	            {
	            	JOptionPane.showMessageDialog(frameFirst, "Invalid property..");
	            }
	           
	            else {
	            	f1=null;
	            try {
	            	int flag=0;
					
	            	if(op1=="EF")
		            {
	            		File f=new File(fname);
	            		if(f.exists()) {
		            	FileReader readFile=new FileReader(fname);
		            	int i;
		            	char c;
		            	i=readFile.read();
		            	c=(char)i;
		            	if(c=='A') {
		            		JOptionPane.showMessageDialog(frameFirst, "Property must be in global form..");
		            		flag=1;
		            	}
		            	readFile.close();
	            		}
		            }
	            	else if(op1=="AG")
	            	{
	            		File f=new File(fname);
	            		if(f.exists()) {
	            	
	            		FileReader readFile=new FileReader(fname);
	            		
		            	int i;
		            	char c;
		            	i=readFile.read();
		            	c=(char)i;
		            	if(c=='E') {
		            		JOptionPane.showMessageDialog(frameFirst, "Property must be in existential form..");
		            		flag=1;
		            	}
		            	readFile.close();
	            		}
	            	}
	            	if(flag==0){
				f1=new BufferedWriter(new FileWriter(fname,true));
				f1.write(op1+" "+dependee+" "+op2+" "+depender);
				f1.newLine();
				f1.close();
	            	}
				}
				catch(IOException ioe) {
					
					ioe.printStackTrace();
				}
	            
	            O1.setSelectedItem("");
	            O2.setSelectedItem("");
	            G1.setSelectedItem("");
	            G2.setSelectedItem("");
	            }
	        }  
	        });
	     	delete.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            String actor=actorlist.getSelectedItem().toString();
	            String fname="c:\\\\CompliantFSM\\\\"+actor+"CTL.txt";
	            //JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	            String props=property.getSelectedItem().toString();
	         
	            if(props=="") {
	            	JOptionPane.showMessageDialog(frameFirst, "Select a property..");
	            }
	            
	            else {
	            BufferedWriter f1=null;
	            try {
				FileReader f2=new FileReader(fname);
				f1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\temp.txt",false));
				int i;
				char c;
				String temp="";
				int delflag=0;
				while((i=f2.read())!=-1) {
					temp="";
					c=(char)i;
					temp=temp.concat(Character.toString(c));
					while((i=f2.read())!=10)
					{
						if(i==-1)
							break;
						c=(char)i;
						if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32 || i==61  || i==46) {
						temp=temp.concat(Character.toString(c));
						}
					}
					if(temp.compareTo(props)!=0 && i!=-1 && delflag==0) {
						System.out.println("temp= "+temp);
						System.out.println("prop is= "+props);
						f1.write(temp);
						f1.newLine();
					}
					else if(temp.compareTo(props)==0 && delflag==0) {
						delflag=1;
					}
					else if(temp.compareTo(props)==0 && delflag==1)
					{
						f1.write(temp);
						f1.newLine();
					}
				}
				
				f1.close();
				f2.close();
				f2=new FileReader("c:\\\\CompliantFSM\\\\temp.txt");
				f1=new BufferedWriter(new FileWriter(fname,false));
				while((i=f2.read())!=-1)
				{
					c=(char)i;
					f1.write(c);
				}
				f1.close();
				f2.close();
				
		   		
		   		
	            }
				catch(IOException ioe) {
					
					ioe.printStackTrace();
				}	
	            }
	        }  
	        });
	     	edit.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	           // String fname="InterActorCTL.txt";
	            //JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	            String props=property.getSelectedItem().toString();
	            deleted=props;
	            String s,t;
	            String actor=actorlist.getSelectedItem().toString();
	            if(props=="") {
	            	JOptionPane.showMessageDialog(frameFirst, "Select a property..");
	            }
	            else {
	            	if(actor.compareTo("InterActor")!=0) {
	            		J.setSelectedItem(actor);
	            		String op1,op2,dependee,depender;
	            		char[] temps=props.toCharArray();
	            		op1="";
            			op2="";
            			dependee="";
            			depender="";
	            		int n=temps.length;
	            		int j=0;
	            		while(j<n) {
	            			op1="";
	            			op2="";
	            			dependee="";
	            			depender="";
	            			while(temps[j]!=' ')
	            			{
	            				op1=op1.concat(Character.toString(temps[j]));
	            				j++;
	            			}
	            			j++;
	            			while(temps[j]!=' ')
	            			{
	            				dependee=dependee.concat(Character.toString(temps[j]));
	            				j++;
	            			}
	            			j++;
	            			while(temps[j]!=' ')
	            			{
	            				op2=op2.concat(Character.toString(temps[j]));
	            				j++;
	            			}
	            			j++;
	            			while(j<n)
	            			{
	            				depender=depender.concat(Character.toString(temps[j]));
	            				j++;
	            			}
	            		}
	            		 G1.removeAllItems();
	      	           G2.removeAllItems();
	      	           G1.addItem("");
	      	           G2.addItem("");
	      	    	 //  JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	      	           FileReader f1=null;
	      	           try {
	      	        	    f1=new FileReader("c:\\\\CompliantFSM\\\\"+actor+".txt");
	      	        	   int i;
	      	        	   char c;
	      	        	   int count=1;
	      	        	   String temp=null;
	      	        	 
	      	        	  // System.out.println("hiee");
	      	        	   while((i=f1.read())!=-1) // Loop to read the entire input file
	      	        	   {
	      	   			c=(char)i;
	      	   			//System.out.println(c);
	      	   			//System.out.println(c+"int="+i);
	      	   			temp="";
	      	   			temp=temp.concat(Character.toString(c));
	      	   			while((i=f1.read())!=10) {
	      	   				c=(char)i;
	      	   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32){
	      	   				temp=temp.concat(Character.toString(c));
	      	   				}
	      	   			}
	      	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	      	  		//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	    	   			char[] copy=temp.toCharArray();
	    	   		
	    	   			s="";
	    	   			j=0;
	    	   			while(copy[j]!=' ') {
	    	   				s=s.concat(Character.toString(copy[j]));
	    	   				j++;
	    	   			}
	    	   			s=s.concat("=FU");
	    	   			if(count>1) {
	    	   			G1.addItem(s);
	    	   			G2.addItem(s);
	    	   			}
	    	   			count++;
	      	   		
	      	   		}
	      	   		f1.close();
	      	   		}
	      	   		catch(IOException e2) {
	      	   		   System.out.println("hello");	
	      	   		} 
	      	       
	      	        
	            		O1.setSelectedItem(op1);
	            		O2.setSelectedItem(op2);
	            		G1.setSelectedItem(dependee);
	            		G2.setSelectedItem(depender);
	            		
	            	}
	            	else {
	            		char [] st=props.toCharArray();
	            		int len=st.length;
	            		String dp1,dp2,g1,g2;
	            		t="";
	            		dp1="";
	            		dp2="";
	            		g1="";
	            		g2="";
	            		int j=0;
	            		while(st[j]!=' ')
	            		{
	            		j++;	
	            		}
	            		j++;
	            		while(st[j]!='.')
	            		{
	            			dp1=dp1.concat(Character.toString(st[j]));
	            		j++;	
	            		}
	            		j++;
	            		while(st[j]!=' ')
	            		{
	            			g1=g1.concat(Character.toString(st[j]));
	            		j++;	
	            		}
	            		j++;
	            		while(st[j]!=' ')
	            		{
	            			t=t.concat(Character.toString(st[j]));
	            		j++;	
	            		}
	            		j++;
	            		while(st[j]!='.')
	            		{
	            			dp2=dp2.concat(Character.toString(st[j]));
	            		j++;	
	            		}
	            		j++;
	            		while(j<len)
	            		{
	            			g2=g2.concat(Character.toString(st[j]));
	            		j++;	
	            		}
	            		A1.setSelectedItem(dp1);
	            		A2.setSelectedItem(dp2);
	            		O3.setSelectedItem(t);
	            		try {
	            		 FileReader f1=null;
	            		 f1=new FileReader("c:\\\\CompliantFSM\\\\"+dp1+".txt");
	      	        	   int i;
	      	        	   char c;
	      	        	   int count=1;
	      	        	   String temp=null;
	      	        	 
	      	        	  // System.out.println("hiee");
	      	        	   while((i=f1.read())!=-1) // Loop to read the entire input file
	      	        	   {
	      	   			c=(char)i;
	      	   			//System.out.println(c);
	      	   			//System.out.println(c+"int="+i);
	      	   			temp="";
	      	   			temp=temp.concat(Character.toString(c));
	      	   			while((i=f1.read())!=10) {
	      	   				c=(char)i;
	      	   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32){
	      	   				temp=temp.concat(Character.toString(c));
	      	   				}
	      	   			}
	      	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	      	  		//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	    	   			char[] copy=temp.toCharArray();
	    	   		
	    	   				t="";
	    	   			s="";
	    	   			j=0;
	    	   			len=copy.length;
	    	   			while(copy[j]!=' ') {
	    	   				s=s.concat(Character.toString(copy[j]));
	    	   				j++;
	    	   			}
	    	   			j++;
	    	   			while(j<len) {
	    	   				t=t.concat(Character.toString(copy[j]));
	    	   				j++;
	    	   			}
	    	   			s=s.concat("=FU");
	    	   			if(t.compareTo("none")!=0) {
	    	   			Go1.addItem(s);
	    	   			
	    	   			}
	    	   			
	      	   		
	      	   		
	            	}
	      	        f1=new FileReader("c:\\\\CompliantFSM\\\\"+dp2+".txt");
	      	        	   
	      	        	  
	      	        	   temp=null;
	      	        	 
	      	        	  // System.out.println("hiee");
	      	        	   while((i=f1.read())!=-1) // Loop to read the entire input file
	      	        	   {
	      	   			c=(char)i;
	      	   			//System.out.println(c);
	      	   			//System.out.println(c+"int="+i);
	      	   			temp="";
	      	   			temp=temp.concat(Character.toString(c));
	      	   			while((i=f1.read())!=10) {
	      	   				c=(char)i;
	      	   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32){
	      	   				temp=temp.concat(Character.toString(c));
	      	   				}
	      	   			}
	      	   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	      	  		//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
	    	   			char[] copy=temp.toCharArray();
	    	   			 t="";
	    	   			s="";
	    	   			j=0;
	    	   			len =copy.length;
	    	   			while(copy[j]!=' ') {
	    	   				s=s.concat(Character.toString(copy[j]));
	    	   				j++;
	    	   			}
	    	   			j++;
	    	   			while(j<len) {
	    	   				t=t.concat(Character.toString(copy[j]));
	    	   				j++;
	    	   			}
	    	   			s=s.concat("=FU");
	    	   			if(t.compareTo("none")!=0) {
	    	   			Go2.addItem(s);
	    	   			
	    	   			}
	    	   			
	           
	           }
	      	        	   Go1.setSelectedItem(g1);
	      	        	   Go2.setSelectedItem(g2);
	          }
	            		catch(IOException ek) {
	            			
	            		}
	        } 
	      }
	            }
	        });
	     	submit2.addActionListener(new ActionListener(){  
	            public void actionPerformed(ActionEvent e){  
	            String fname="c:\\\\CompliantFSM\\\\InterActorCTL.txt";
	            //JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
	            String op1=O3.getSelectedItem().toString();
	            String dependee=A1.getSelectedItem().toString();
	            String depender=A2.getSelectedItem().toString();
	            String G1=Go1.getSelectedItem().toString();
	            String G2=Go2.getSelectedItem().toString();
	            BufferedWriter f1=null;
	            if(deleted!="") {
		            try {
					FileReader f2=new FileReader(fname);
					f1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\temp.txt",false));
					int i;
					char c;
					String temp="";
					while((i=f2.read())!=-1) {
						temp="";
						c=(char)i;
						temp=temp.concat(Character.toString(c));
						while((i=f2.read())!=10)
						{
							if(i==-1)
								break;
							c=(char)i;
							if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32 || i==61 || i==46) {
							temp=temp.concat(Character.toString(c));
							}
						}
						if(temp.compareTo(deleted)!=0 && i!=-1) {
							System.out.println("temp= "+temp);
							System.out.println("prop is= "+deleted);
							f1.write(temp);
							f1.newLine();
						}
					}
					
					f1.close();
					f2.close();
					f2=new FileReader("c:\\\\CompliantFSM\\\\temp.txt");
					f1=new BufferedWriter(new FileWriter(fname,false));
					while((i=f2.read())!=-1)
					{
						c=(char)i;
						f1.write(c);
					}
					f1.close();
					f2.close();
					 property.removeAllItems();
			           property.addItem("");
			    	 //  JOptionPane.showMessageDialog(frameFirst, "The filename is "+fname);
			       
			        	    f2=new FileReader(fname);
			        	  
			        	  temp="";
			        	 
			        	  // System.out.println("hiee");
			        	   while((i=f2.read())!=-1) // Loop to read the entire input file
			        	   {
			   			c=(char)i;
			   			//System.out.println(c);
			   			//System.out.println(c+"int="+i);
			   			temp="";
			   			temp=temp.concat(Character.toString(c));
			   			while((i=f2.read())!=10) {
			   				c=(char)i;
			   				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==32 || i==61 || i==46){
			   				temp=temp.concat(Character.toString(c));
			   				}
			   			}
			   			//JOptionPane.showMessageDialog(frameFirst, "Goal is "+temp);
			   			property.addItem(temp);
			   		
			   		}
			   		f1.close();
			   		
			   		
		            }
					catch(IOException ioe) {
						
						ioe.printStackTrace();
					}	
		            deleted="";
		           }
	            if(dependee.compareTo(depender)==0 || dependee=="" || depender=="" || op1=="" || G1=="" || G2=="") {
	            	JOptionPane.showMessageDialog(frameFirst, "Invalid property..");
	            }
	            else {
	             f1=null;
	            try {
					
				f1=new BufferedWriter(new FileWriter(fname,true));
				f1.write("AG "+dependee+"."+G1+" "+op1+" "+depender+"."+G2);
				f1.newLine();
				f1.close();
	            }
				catch(IOException ioe) {
					
					ioe.printStackTrace();
				}	
	            O3.setSelectedItem("");
	            A1.setSelectedItem("");
	            A2.setSelectedItem("");
	            Go1.setSelectedItem("");
	            Go2.setSelectedItem("");
	           }
	        }  
	        });
	     	frameFirst.setVisible(true);
	     /*	while(working==0) {
	     		System.out.println("");
	     	}*/
	  
	  
	}
	public static void generate_input()
	{
		FileReader f1=null;
		FileReader f2=null;
		BufferedWriter b1=null;
		try {
		f1=new FileReader(selected_file);
		b1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\temp_input.ndsl",false));
		int i;
		char c;
		String temp="";
		int j=1;
		while(j<=9) {
		i=f1.read();
		c=(char)i;
		b1.write(c);
		j++;
		}
		int count_braces=0;
		count_braces++;
		while((i=f1.read())!=-1) {
			
			if(i!=-1) {
				c=(char)i;
				b1.write(c);
			}
			while((i=f1.read())!=111 ) {
				c=(char)i;
				if(i==-1)
					break;
				b1.write(c);
			}
		
			temp="c:\\\\CompliantFSM\\\\";
			if(i!=-1) {
			c=(char)i;
			b1.write(c);
			i=f1.read();
			c=(char)i;
			b1.write(c);
			
			i=f1.read();
			c=(char)i;
			b1.write(c);
			i=f1.read();
			c=(char)i;
			b1.write(c);
			
			temp=temp.concat(Character.toString(c));
			}
			else
				break;
			while((i=f1.read())!=123 ){
				if(i==-1)
					break;
				c=(char)i;
				b1.write(c);
				if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95)
				temp=temp.concat(Character.toString(c));
			}
			count_braces++;
			if(i!=-1) {
			c=(char)i;
			b1.write(c);
			temp=temp.concat("CTL.txt");
			}
			//System.out.println("Temp here is"+temp);
			String ctl="";
			try {
				f2=new FileReader(temp);
				int noCTL=0;
				while((i=f2.read())!=-1) {
					if(i==10)
						noCTL++;
				}
				System.out.println("number of CTL is"+noCTL);
				f2.close();
			
				String type="";
				f2=new FileReader(temp);
				while((i=f2.read())!=-1) {
						c=(char)i;
						if(c=='A') {
							ctl=ctl.concat("AG(");
							String dependee="";
							String depender="";
							if(noCTL==1) {
								ctl=ctl.concat("(");
								i=f2.read();
								i=f2.read();
								i=f2.read();
								c=(char)i;
								System.out.println("c is"+c);
								dependee=dependee.concat(Character.toString(c));
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									dependee=dependee.concat(Character.toString(c));
								}
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									type=type.concat(Character.toString(c));
								}
								while((i=f2.read())!=10) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									depender=depender.concat(Character.toString(c));
								}
								if(type.compareTo("AF")==0 || type.compareTo("AX")==0) {
									ctl=ctl.concat(dependee);
									ctl=ctl.concat(") -> ");
									ctl=ctl.concat(type);
									ctl=ctl.concat("(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat("))");
									
								}
								else if(type.compareTo("U")==0)
								{
									ctl=ctl.concat("NOT(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat(") U (");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat("))");
								}
							}
							else if(noCTL>1) 
							{
								
							int index=noCTL;
							while(i!=-1) {
								dependee="";
								depender="";
								ctl=ctl.concat("(");
								i=f2.read();
								i=f2.read();
								i=f2.read();
								c=(char)i;
								System.out.println("c here is"+c);
								dependee=dependee.concat(Character.toString(c));
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									dependee=dependee.concat(Character.toString(c));
								}
								type="";
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									type=type.concat(Character.toString(c));
								}
								while((i=f2.read())!=10) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									depender=depender.concat(Character.toString(c));
								}
								i=f2.read();
								if(type.compareTo("AF")==0 || type.compareTo("AX")==0) {
									ctl=ctl.concat("(");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat(") -> ");
									ctl=ctl.concat(type);
									ctl=ctl.concat("(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat("))");
									
								}
								else if(type.compareTo("U")==0)
								{
									ctl=ctl.concat("NOT(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat(") U (");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat("))");
									
								}
								index--;
								//System.out.println("The index value is"+index);
								if(index>0) {
									ctl=ctl.concat(" AND ");
									}
								else {
									ctl=ctl.concat(")");
								}
							}
							}
							
						}
						else if(c=='E') {
							ctl=ctl.concat("NOT(EF(");
							String dependee="";
							String depender="";
							if(noCTL==1) {
								i=f2.read();
								i=f2.read();
								i=f2.read();
								c=(char)i;
								System.out.println("c is"+c);
								dependee=dependee.concat(Character.toString(c));
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									dependee=dependee.concat(Character.toString(c));
								}
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									type=type.concat(Character.toString(c));
								}
								while((i=f2.read())!=10) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									depender=depender.concat(Character.toString(c));
								}
								if(type.compareTo("EF")==0 || type.compareTo("EX")==0) {
									ctl=ctl.concat("(");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat(") AND ");
									ctl=ctl.concat(type);
									ctl=ctl.concat("(NOT(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat("))))");
									
								}
								else if(type.compareTo("U")==0)
								{
									ctl=ctl.concat("(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat(") AND (NOT(");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat("))))");
								}
							}
							else if(noCTL>1) 
							{
								
							int index=noCTL;
							while(i!=-1) {
								dependee="";
								depender="";
								ctl=ctl.concat("(");
								i=f2.read();
								i=f2.read();
								i=f2.read();
								c=(char)i;
								System.out.println("c here is"+c);
								dependee=dependee.concat(Character.toString(c));
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									dependee=dependee.concat(Character.toString(c));
								}
								type="";
								while((i=f2.read())!=32) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									type=type.concat(Character.toString(c));
								}
								while((i=f2.read())!=10) {
									c=(char)i;
									if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
									depender=depender.concat(Character.toString(c));
								}
								i=f2.read();
								if(type.compareTo("EF")==0 || type.compareTo("EX")==0) {
								
									ctl=ctl.concat("(");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat(") AND ");
									ctl=ctl.concat(type);
									ctl=ctl.concat("(NOT(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat(")))");
								}
								else if(type.compareTo("U")==0)
								{
									ctl=ctl.concat("(");
									ctl=ctl.concat(depender);
									ctl=ctl.concat(") AND (NOT(");
									ctl=ctl.concat(dependee);
									ctl=ctl.concat(")))");
									
								}
								index--;
								//System.out.println("The index value is"+index);
								if(index>0) {
									ctl=ctl.concat(" AND ");
									}
								else {
									ctl=ctl.concat("))");
								}
							}
						}
							
						}
					
				}
			System.out.println("the CTL is"+ctl);	
			}
			catch(IOException es) {
				System.out.println("File does not exists");
				
			}
		
		int iprev=0;
		i=f1.read();
		c=(char)i;
		b1.write(c);
		
			while((i=f1.read())!=-1){
				if(i==-1)
					break;
				if(i==123)
					count_braces++;
				else if(i==125)
					count_braces--;
				if(count_braces==1)
					break;
				c=(char)i;
				b1.write(c);
				iprev=i;
			
			}
		if(ctl!="") {
		b1.write("ctl '");
		b1.write(ctl);
		b1.write("'");
		ctl="";
		System.out.println("the value of braces is"+count_braces);
		}
		if(i!=-1) {
		b1.newLine();
		b1.write("\t");
		c=(char)i;
		b1.write("}");
		}
						
		}
		f1.close();
		b1.close();
		}
		catch(IOException e) {
			System.out.println("Unreachable 1");
		}
		try {
			f1=new FileReader("c:\\\\CompliantFSM\\\\temp_input.ndsl");
			b1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\temp_input2.ndsl",false));
			int count_braces=0;
			int i;
			char c;
			String ctl="";
			int flag=1;
			int p=0;
			while((i=f1.read())!=-1) {
				c=(char)i;
				if(c=='{') {
					count_braces++;
					flag=0;
				}
				else if(c=='}')
				{
					count_braces--;
					
				}
				
				if(count_braces==0 && flag!=1) {
					p++;
					f2=new FileReader("c:\\\\CompliantFSM\\\\InterActorCTL.txt");
					
					int noCTL=0;
			
					while((i=f2.read())!=-1) {
						if(i==10)
							noCTL++;
					}
					System.out.println("Number of Inter-actor CTL is"+noCTL);	
					f2.close();
						ctl="";
						
						int index=noCTL;
						String type="";
						f2=new FileReader("c:\\\\CompliantFSM\\\\InterActorCTL.txt");
						if(noCTL==1) {
							ctl=ctl.concat("CTLActor 'AG(");
							dependee="";
							depender="";
							i=f2.read();
							i=f2.read();
							i=f2.read();
							i=f2.read();
							c=(char)i;
							//System.out.println("c here is"+c);
							dependee=dependee.concat(Character.toString(c));
							while((i=f2.read())!=32) {
								c=(char)i;
								if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
								dependee=dependee.concat(Character.toString(c));
							}
							type="";
							while((i=f2.read())!=32) {
								c=(char)i;
								if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
								type=type.concat(Character.toString(c));
							}
							while((i=f2.read())!=10) {
								c=(char)i;
								if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
								depender=depender.concat(Character.toString(c));
							}
							i=f2.read();
							f2.close();
												
								ctl=ctl.concat("(");
								ctl=ctl.concat(dependee);
								ctl=ctl.concat(") -> ");
								ctl=ctl.concat(type);
								ctl=ctl.concat("(");
								ctl=ctl.concat(depender);
								ctl=ctl.concat("))'");
								
						}
		
						if(noCTL>1) {
							ctl=ctl.concat("CTLActor 'AG(");
							System.out.println("peeeeppp");
							i=f2.read();
						while(i!=-1) {
							dependee="";
							depender="";
							ctl=ctl.concat("(");
							i=f2.read();
							i=f2.read();
							i=f2.read();
							c=(char)i;
							//System.out.println("c here is"+c);
							dependee=dependee.concat(Character.toString(c));
							while((i=f2.read())!=32) {
								c=(char)i;
								if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
								dependee=dependee.concat(Character.toString(c));
							}
							type="";
							while((i=f2.read())!=32) {
								c=(char)i;
								if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
								type=type.concat(Character.toString(c));
							}
							while((i=f2.read())!=10) {
								c=(char)i;
								if((i>=65 && i<=90)||(i>=97 && i<=122) || i==95 || i==61 || i==46)
								depender=depender.concat(Character.toString(c));
							}
							i=f2.read();
							
								ctl=ctl.concat("(");
								ctl=ctl.concat(dependee);
								ctl=ctl.concat(") -> ");
								ctl=ctl.concat(type);
								ctl=ctl.concat("(");
								ctl=ctl.concat(depender);
								ctl=ctl.concat("))");
								System.out.println("Done here");
							index--;
							if(index>0) {
								ctl=ctl.concat(" AND ");
								}
							else {
								ctl=ctl.concat(")'");
								break;
							}
						
						}
					
					
					
						}
				
						b1.write("\t");
						b1.write(ctl);
						b1.newLine();
						b1.write("}");
						break;
				}
				else {
					b1.write(c);
				
				}
				
			}
			System.out.println("P is"+p);
			f1.close();
			b1.close();
			f1=new FileReader("c:\\\\CompliantFSM\\\\temp_input2.ndsl");
			b1=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\temp_input.ndsl",false));
			while((i=f1.read())!=-1)
			{
				c=(char)i;
				b1.write(c);
			}
			f1.close();
			b1.close();
		}
		catch(IOException e) {
			System.out.println("Not Found");
		}
	}
	public static void copy_input()
	{
		
	FileReader f1=null;
	BufferedWriter b1=null;
		try {
			f1=new FileReader("c:\\\\CompliantFSM\\\\temp_input.ndsl");
			b1=new BufferedWriter(new FileWriter(selected_file,false));
			int i;
			char c;
			while((i=f1.read())!=-1) {
				c=(char)i;
				b1.write(c);
			}
			f1.close();
			b1.close();
		}
		catch(IOException e) {
			System.out.println("unreachable 2");
		}
		
	}
static int working2;
static int flagback;
	public static void setFSM_name(String s)
	{
		//frameFirst.setVisible(false);
		ctltypeflag=0;
		tempex="";
	selected=0;
	working2=0;
	flagback=0;
	textArea.setText(null);
	textArea2.setText(null);
	textArea3.setText(null);
	textCTL.setText(null);
	andnum.setText(null);
	andchild.setText(null);
	ornum.setText(null);
	orchild.setText(null);
	texttransitions.setText(null);
	texttransitions2.setText(null);
	textpaths.setText(null);
	textpaths2.setText(null);
	textTime.setText(null);
	textTime2.setText(null);
	reduceTransition.setText(null);
	reducePaths.setText(null);
	nodes.setText(null);
	generateFSM.setEnabled(true);
		
        try { 
  
          
        	UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch (Exception e) { 
            System.out.println("Look and Feel not set"); 
        } 
        FileReader f1=null;
        try {
        	f1=new FileReader(selected_file);
        	BufferedReader br=new BufferedReader(f1);
           	textArea2.read(br,null);
           	br.close();
           	textArea2.requestFocus();
        }
        catch(IOException ioe){
        	
        }
		 //JFrame.setDefaultLookAndFeelDecorated(true);
		//JFrame frame1=new JFrame("My application"); 
		  frame1.setLayout(null);
		  frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		  frame1.setBounds(-15, -6, 4500, 4500);
	        //frame1.setSize(2300, 2300);
	        frame1.getContentPane().setBackground(new Color(255,255,153));
		 JPanel buttonPanel=new JPanel();
		  buttonPanel.setBounds(10, 50, 880, 110);
		  buttonPanel.setLayout(null);
		  buttonPanel.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
			 buttonPanel.setBackground(new Color(255,255,204));

		       generateFSM.setFont(new Font("Calibri", Font.ITALIC, 16));
		       generateFSM.setBackground(new Color(255,204,0));
		       generateFSM.setForeground(Color.black);
		       generateFSM.setBounds(20, 10, 140, 90);
		
		       save_button.setFont(new Font("Calibri", Font.ITALIC, 16));
		       save_button.setBackground(new Color(255,204,0));
		       save_button.setForeground(Color.black);
		       
		       /* output_file_button.setFont(new Font("Calibri", Font.ITALIC, 16));
		        output_file_button.setBackground(new Color(255,204,0));
		        output_file_button.setForeground(Color.black);
		        output_file_button.setBounds(170, 10, 160, 40);
		        output_file_button.setEnabled(false);*/
		        output_file_button2.setFont(new Font("Calibri", Font.ITALIC, 16));
		        output_file_button2.setBackground(new Color(255,204,0));
		        output_file_button2.setForeground(Color.black);
		        output_file_button2.setBounds(170, 60, 160, 40);
		   	 	output_file_button2.setEnabled(false);;
		       /* checkNuSMV_button.setFont(new Font("Calibri", Font.ITALIC, 16));
		        checkNuSMV_button.setBackground(new Color(255,204,0));
		        checkNuSMV_button.setForeground(Color.black);
		        checkNuSMV_button.setBounds(340,10, 220, 40);
		   	 	checkNuSMV_button.setEnabled(false);*/
		        checkNuSMV_button2.setFont(new Font("Calibri", Font.ITALIC, 16));
		        checkNuSMV_button2.setBackground(new Color(255,204,0));
		        checkNuSMV_button2.setForeground(Color.black);
		        checkNuSMV_button2.setBounds(340, 60, 220, 40);
		   	 	checkNuSMV_button2.setEnabled(false);;
		       /* validate_button.setFont(new Font("Calibri", Font.ITALIC, 16));
		        validate_button.setBackground(new Color(255,204,0));
		        validate_button.setForeground(Color.black);
		       validate_button.setBounds(570, 10, 300, 40);
		  	 	validate_button.setEnabled(false);*/
		        validate_button2.setFont(new Font("Calibri", Font.ITALIC, 16));
		        validate_button2.setBackground(new Color(255,204,0));
		        validate_button2.setForeground(Color.black);
		       validate_button2.setBounds(570, 60, 300, 40);
		  	 	validate_button2.setEnabled(false);
		        back.setBackground(new Color(255,204,0));
		        back.setForeground(Color.black);
		       back.setBounds(220, 6, 120, 30);
		  	 	back.setEnabled(true);
		  	 	//frame1.add(back);
		       buttonPanel.add(Box.createRigidArea(new Dimension(20,0)));
		        buttonPanel.add(generateFSM);
		      //  buttonPanel.add(Box.createRigidArea(new Dimension(20,0)));
		        //buttonPanel.add(output_file_button);
		        buttonPanel.add(Box.createRigidArea(new Dimension(20,0)));
		        buttonPanel.add(output_file_button2);
		        //buttonPanel.add(Box.createRigidArea(new Dimension(20,0)));
		        //buttonPanel.add(checkNuSMV_button);
		        buttonPanel.add(Box.createRigidArea(new Dimension(20,0)));
		        buttonPanel.add(checkNuSMV_button2);
		       // buttonPanel.add(Box.createRigidArea(new Dimension(20,0)));
		        //buttonPanel.add(validate_button);
		        buttonPanel.add(validate_button2);
		        label7.setFont(new Font("Calibri", Font.BOLD, 20));
			      label7.setBounds(10,-2,200,50);
			      textpaths.setFont(new Font("Calibri", Font.BOLD, 20));
			      texttransitions.setFont(new Font("Calibri", Font.BOLD, 20));
			      textpaths2.setFont(new Font("Calibri", Font.BOLD, 20));
			      texttransitions2.setFont(new Font("Calibri", Font.BOLD, 20));
			      textTime.setFont(new Font("Calibri", Font.BOLD, 20));
			      textTime2.setFont(new Font("Calibri", Font.BOLD, 20));
			      reduceTransition.setFont(new Font("Calibri", Font.BOLD, 20));
			      reducePaths.setFont(new Font("Calibri", Font.BOLD, 20));
			      
					frame1.add(label7);
		  frame1.add(buttonPanel);
		label4.setFont(new Font("Calibri", Font.BOLD, 20));
		label4.setBounds(1000, 0,150,50);
		frame1.add(label4);
		label1.setFont(new Font("Calibri", Font.ITALIC, 20));
		label1.setBounds(1000, 15,200,100);
		frame1.add(label1);
		  scrollPane2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		  scrollPane2.setPreferredSize(new Dimension(800,100));
		  JPanel textPanel2=new JPanel();
		  scrollPane2.setBounds(1000, 90, 900, 100);
		  textCTL.setEditable(false);
		  frame1.add(scrollPane2);
		  label10.setFont(new Font("Calibri", Font.ITALIC, 20));
			label10.setBounds(10, 720,200,50);
			label11.setFont(new Font("Calibri", Font.ITALIC, 20));
			label11.setBounds(10, 780,200,50);
			frame1.add(label10);
			frame1.add(label11);
			label19.setFont(new Font("Calibri", Font.ITALIC, 20));
			label19.setBounds(10, 840,200,50);
			label20.setFont(new Font("Calibri", Font.ITALIC, 20));
			label20.setBounds(10, 670,200,50);
			frame1.add(label20);
			frame1.add(label19);
			label2.setFont(new Font("Calibri", Font.ITALIC, 20));
			label2.setBounds(150, 680,200,50);
			frame1.add(label2);
			texttransitions.setBounds(150, 720, 100, 40);
			frame1.add(texttransitions);
			texttransitions2.setBounds(150, 780, 100, 40);
			frame1.add(texttransitions2);
			reduceTransition.setBounds(150, 840, 100, 40);
			frame1.add(reduceTransition);
			reduceTransition.setEditable(false);
			label3.setFont(new Font("Calibri", Font.ITALIC, 20));
			label3.setBounds(270, 680,400,50);
			frame1.add(label3);
			label12.setFont(new Font("Calibri", Font.ITALIC, 20));
			label12.setBounds(430, 680,400,50);
			frame1.add(label12);
			label13.setFont(new Font("Calibri", Font.ITALIC, 20));
			label13.setBounds(620, 680,400,50);
			frame1.add(label13);
			label14.setFont(new Font("Calibri", Font.ITALIC, 20));
			label14.setBounds(600, 740,400,50);
			frame1.add(label14);
			label17.setFont(new Font("Calibri", Font.ITALIC, 20));
			label17.setBounds(800, 740,400,50);
			frame1.add(label17);
			label18.setFont(new Font("Calibri", Font.ITALIC, 20));
			label18.setBounds(920, 740,400,50);
			frame1.add(label18);
			label15.setFont(new Font("Calibri", Font.ITALIC, 20));
			label15.setBounds(660,780,400,50);
			frame1.add(label15);
			label16.setFont(new Font("Calibri", Font.ITALIC, 20));
			label16.setBounds(660, 830,400,50);
			frame1.add(label16);
			andnum.setBounds(800, 780, 80, 40);
			frame1.add(andnum);
			andchild.setBounds(900, 780, 80, 40);
			frame1.add(andchild);
			ornum.setBounds(800, 830, 80, 40);
			frame1.add(ornum);
			orchild.setBounds(900, 830, 80, 40);
			frame1.add(orchild);
			save_button.setBounds(660, 900, 150, 40);
			frame1.add(save_button);
			save_button.setEnabled(false);
			nodes.setBounds(700, 680, 100, 40);
			frame1.add(nodes);
			textpaths.setBounds(290, 720, 100, 40);
			frame1.add(textpaths);
			textpaths2.setBounds(290, 780, 100, 40);
			frame1.add(textpaths2);
			reducePaths.setBounds(290, 840, 100, 40);
			frame1.add(reducePaths);
			reducePaths.setEditable(false);
			textTime.setBounds(450, 720, 100, 40);
			frame1.add(textTime);
			textTime2.setBounds(450, 780, 100, 40);
			frame1.add(textTime2);
			label5.setFont(new Font("Calibri", Font.ITALIC, 20));
			label5.setBounds(1000, 450,200,50);
			frame1.add(label5);
			andnum.setFont(new Font("Calibri", Font.BOLD, 20));
			andchild.setFont(new Font("Calibri", Font.BOLD, 20));
			ornum.setFont(new Font("Calibri", Font.BOLD, 20));
			orchild.setFont(new Font("Calibri", Font.BOLD, 20));
			nodes.setFont(new Font("Calibri", Font.BOLD, 20));
			 texttransitions.setEditable(false);
			 textpaths.setEditable(false);
			 texttransitions2.setEditable(false);
			 textpaths2.setEditable(false);
			 textTime.setEditable(false);
			 textTime2.setEditable(false);
			 scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		      scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		      textArea.setEditable(false);
		      textArea2.setEditable(false);
		      nodes.setEditable(false);
		      scrollPane.setBounds(1000, 495, 900, 500);  
		      frame1.add(scrollPane);
		      label6.setFont(new Font("Calibri", Font.BOLD, 20));
		      label6.setBounds(10, 160,200,50);
				frame1.add(label6);
			    label8.setFont(new Font("Calibri", Font.ITALIC, 20));
			      label8.setBounds(10, 190,400,50);
					frame1.add(label8);
				scrollPane3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			      scrollPane3.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			      scrollPane3.setBounds(10, 240, 890, 400); 
			      frame1.add(scrollPane3);
			     label9.setFont(new Font("Calibri", Font.ITALIC, 20));
			     label9.setBounds(1000, 200,250,50);
					frame1.add(label9);
					scrollPane4.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				      scrollPane4.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				      scrollPane4.setBounds(1000, 240, 890, 200); 
			      textArea3.setLineWrap(true);
			      textArea3.setEditable(false);
			      andnum.setEditable(false);
			      andchild.setEditable(false);
			      ornum.setEditable(false);
			      orchild.setEditable(false);
			      frame1.add(scrollPane4);
			      validate_button.setToolTipText("Click To Cross Verify Model");
			        checkNuSMV_button.setToolTipText("Click To See NuSMV Input");
			        output_file_button.setToolTipText("Click To See Finite State Model");
			       input_file_button.setToolTipText("Click To Load Input");
		
			       save_button.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){  
			            
			            	File dir = new File("c:\\\\CompliantFSM\\\\Metrics");
			                
			                // attempt to create the directory here
			                boolean successful = dir.mkdir();
			                if (successful)
			                {
			                  // creating the directory succeeded
			                  System.out.println("directory was created successfully");
			                  BufferedWriter outputMetrics=null;
			                  try {
			                	  float reduce1=((float)(transitionsSIA-transitionsmSIA)/(float)transitionsSIA)*100;
			      				float reduce2=((float)(pathSIA-pathtemp)/(float)pathSIA)*100;
			                 String s1=Float.toString(reduce1);
			                 String s2=Float.toString(reduce2);
			      				outputMetrics=new BufferedWriter(new FileWriter("c:\\\\CompliantFSM\\\\Metrics//Output_metrics.txt",false));
			                  outputMetrics.write("*************************************************************");
			             
			                  outputMetrics.newLine();
			                  outputMetrics.write("Output Metrics");
			                  outputMetrics.newLine();
			                  outputMetrics.write("*************************************************************");
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of nodes: ");
			                  s1=Integer.toString(nodeCount);
			                  outputMetrics.write(s1);
			         
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of AND Decomposition: ");
			                  s1=Integer.toString(andnum1);
			                  outputMetrics.write(s1);
			                  outputMetrics.write(" ||Total Child: ");
			                  s1=Integer.toString(andchild1);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of OR Decomposition: ");
			                  s1=Integer.toString(ornum1);
			                  outputMetrics.write(s1);
			                  outputMetrics.write(" ||Total Child: ");
			                  s1=Integer.toString(orchild1);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of transitions SIA: ");
			                  s1=Integer.toString(transitionsSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of transitions M-SIA: ");
			                  s1=Integer.toString(transitionsmSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Percentage of Reduction of transitions: ");
			                  s1=Float.toString(reduce1);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of execution paths SIA: ");
			                  s1=Integer.toString(pathSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of execution paths M-SIA: ");
			                  s1=Integer.toString(pathtemp);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Percentage of reduction of execution paths: ");
			                  outputMetrics.write(s2);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Execution Time of SIA: ");
			                  s1=Integer.toString(duraSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Execution Time of M-SIA: ");
			                  s1=Integer.toString(duramSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.close();
			                  }
			                  catch(Exception em)
			                  {
			                	 System.out.println("Failed to write"); 
			                  }
			                  
			                }
			                else
			                {
			                  // creating the directory failed
			                  System.out.println("Directory Already Exists");
			                  BufferedWriter outputMetrics=null;
			                  try {
			                	  float reduce1=((float)(transitionsSIA-transitionsmSIA)/(float)transitionsSIA)*100;
			      				float reduce2=((float)(pathSIA-pathtemp)/(float)pathSIA)*100;
			                 String s1=Float.toString(reduce1);
			                 String s2=Float.toString(reduce2);
			      				outputMetrics=new BufferedWriter(new FileWriter("Metrics//Output_metrics.txt",true));
			                  outputMetrics.write("*************************************************************");
			             
			                  outputMetrics.newLine();
			                  outputMetrics.write("Output Metrics");
			                  outputMetrics.newLine();
			                  outputMetrics.write("*************************************************************");
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of nodes: ");
			                  s1=Integer.toString(nodeCount);
			                  outputMetrics.write(s1);
			         
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of AND Decomposition: ");
			                  s1=Integer.toString(andnum1);
			                  outputMetrics.write(s1);
			                  outputMetrics.write(" ||Total Child: ");
			                  s1=Integer.toString(andchild1);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of OR Decomposition: ");
			                  s1=Integer.toString(ornum1);
			                  outputMetrics.write(s1);
			                  outputMetrics.write(" ||Total Child: ");
			                  s1=Integer.toString(orchild1);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of transitions SIA: ");
			                  s1=Integer.toString(transitionsSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of transitions M-SIA: ");
			                  s1=Integer.toString(transitionsmSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Percentage of Reduction of transitions: ");
			                  s1=Float.toString(reduce1);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of execution paths SIA: ");
			                  s1=Integer.toString(pathSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Number of execution paths M-SIA: ");
			                  s1=Integer.toString(pathtemp);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Percentage of reduction of execution paths: ");
			                  outputMetrics.write(s2);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Execution Time of SIA: ");
			                  s1=Integer.toString(duraSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.write("Execution Time of M-SIA: ");
			                  s1=Integer.toString(duramSIA);
			                  outputMetrics.write(s1);
			                  outputMetrics.newLine();
			                  outputMetrics.close();
			                  }
			                  catch(Exception em)
			                  {
			                	 System.out.println("Failed to write"); 
			                  }
			         
			                }
			                save_button.setEnabled(false);
			        }
			           
			        });
			       back.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	initialize();
			        		delete_files();
			            	textAreaF.setText(null);
			               
			            frame1.setVisible(false);
			            frameFirst.repaint();
			      
			      }
			           
			        });

			       output_file_button.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	try {
			            	FileReader read=new FileReader("c:\\\\CompliantFSM\\\\sttSIA.ndsl");

				        	BufferedReader br=new BufferedReader(read);
				        	textArea.setColumns(100);
				        	textArea.read(br,null);
				        	
				        	br.close();
				        	textArea.requestFocus();
			            	}
			            	  catch(Exception es){
			            		  JOptionPane.showMessageDialog(frame1, "Wait for FSM generation...");
			      	        	
			      	        }
			            
			        }  
			        });
			       output_file_button2.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	try {
			            	FileReader read=new FileReader("c:\\\\CompliantFSM\\\\stt.ndsl");

				        	BufferedReader br=new BufferedReader(read);
				        	textArea.setColumns(100);
				        	textArea.read(br,null);
				        	
				        	br.close();
				        	textArea.requestFocus();
			            	}
			            	  catch(Exception es){
			            		  JOptionPane.showMessageDialog(frame1, "Wait for FSM generation...");
			      	        	
			      	        }
			            
			        }  
			        });
			        checkNuSMV_button.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	try {
			            	FileReader read=new FileReader("c:\\\\CompliantFSM\\\\NUSMV_inputSIA.smv");

				        	BufferedReader br=new BufferedReader(read);
				        	textArea.setColumns(100);
				        	textArea.read(br,null);
				        	
				        	br.close();
				        	textArea.requestFocus();
			            	}
			            	  catch(Exception es){
			            		  JOptionPane.showMessageDialog(frame1, "Wait for NuSMV input generation...");
			      	        	
			      	        }
			            
			        }

						  
			        });
			        checkNuSMV_button2.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	try {
			            	FileReader read=new FileReader("c:\\\\CompliantFSM\\\\NUSMV_input.smv");

				        	BufferedReader br=new BufferedReader(read);
				        	textArea.setColumns(100);
				        	textArea.read(br,null);
				        	
				        	br.close();
				        	textArea.requestFocus();
			            	}
			            	  catch(Exception es){
			            		  JOptionPane.showMessageDialog(frame1, "Wait for NuSMV input generation...");
			      	        	
			      	        }
			            
			        }  
			        });
			        generateFSM.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	create_output();
			            	generateFSM.setEnabled(false);
			            
			        }  
			        });
			        validate_button.setToolTipText("Click To Cross Verify Model SIA");
			        checkNuSMV_button.setToolTipText("Click To See NuSMV Input for SIA");
			        output_file_button.setToolTipText("Click To See Finite State Model for SIA");
			        validate_button2.setToolTipText("Click To Cross Verify Model M-SIA");
			        checkNuSMV_button2.setToolTipText("Click To See NuSMV Input for M-SIA");
			        output_file_button2.setToolTipText("Click To See Finite State Model for M-SIA");
			    save_button.setToolTipText("Click To Save Metrics");
			       generateFSM.setToolTipText("Click To generate FSM");
			        validate_button.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	try {
			            		try {
			            			System.out.println("The actor count is"+actcount);
			            			int i=1;
			            			FileReader fexec=new FileReader("c:\\\\CompliantFSM\\\\execCount.txt");
			            			String tp="";
			            			int k;
			            			char c;
			            			while((k=fexec.read())!=-1)
			                    	{
			                    		
			                    		c=(char)k;
			            
			                    			if(k>=48 && k<=57)
			                    				tp=tp.concat(Character.toString(c));
			                    	}
			            			fexec.close();
			                    		
			                    	execCount=Integer.valueOf(tp);
			                 
			                		System.out.println("The exec count in Nusmv"+execCount);
			                		FileReader f1=new FileReader("c://CompliantFSM//type.txt");
			                	 i=f1.read();
			                		 char typec=(char)i;
			                	   	 i=1;
			                		 if(typec=='A') {
			                		while(i<execCount)
			                		{
			                			
			                		Runtime.getRuntime().exec("cmd /k cd C://CompliantFSM/NuSMV/bin && NuSMV -source execS"+i+".txt"); 
			                       System.out.println("NuSMV2 Executed");
			                         i++;
			                		}
			                		 
			                	}
			                		 else if(typec=='E')
			                		 {
			                				Runtime.getRuntime().exec("cmd /k cd C://CompliantFSM/NuSMV/bin && NuSMV -source exec"+i+".txt"); 
						                       System.out.println("NuSMV2 Executed");
						                         i++;
			                		 }
			            			  System.out.println("Output created");
			            			   File file=new File("c://CompliantFSM//Inputsmv//output.txt");
			            	    	   file.delete();
			            	       int j=execCount-1;
			            	       if(typec=='A') {
			            	       while(j>=1)
			            	       {
			            	        	 f1=new FileReader("C:\\CompliantFSM\\Inputsmv\\outputS"+j+".txt");
			            	        	BufferedWriter temp=new BufferedWriter(new FileWriter("c://CompliantFSM//Inputsmv//output.txt",true));
			            	        	 
			            	        	while((i=f1.read())!=-1)
			            	        	{
			            	        		c=(char)i;
			            	        		if(c!='!')
			            	        		temp.write(c);
			            	        	}
			            	        	f1.close();
			            	        	File fl=new File("C:\\CompliantFSM\\Inputsmv\\outputS"+j+".txt");
			            	        	fl.delete();
			            	        			
			            	        	temp.close();
			            	        	j--;
			            	       }
			            	       
			            	      }
			            	       else if(typec=='E') {
			            	    	   while(j>=1)
				            	       {
				            	        	 f1=new FileReader("C:\\CompliantFSM\\Inputsmv\\output"+j+".txt");
				            	        	BufferedWriter temp=new BufferedWriter(new FileWriter("c://CompliantFSM//Inputsmv//output.txt",true));
				            	        	 
				            	        	while((i=f1.read())!=-1)
				            	        	{
				            	        		c=(char)i;
				            	        		if(c=='!') {
				            	        			char c1=c;
				            	        			i=f1.read();
				            	        			c=(char)i;
				            	        			if(c!='=') {
				            	        				temp.write(c1);
				            	        				temp.write(c);
				            	        			}
				            	        			else
				            	        				temp.write(c);
				            	        		}
				            	        		else
				            	        			temp.write(c);
				            	        		
				            	        	}
				            	        	f1.close();
				            	        	File fl=new File("C:\\CompliantFSM\\Inputsmv\\output"+j+".txt");
				            	        	fl.delete();
				            	        			
				            	        	temp.close();
				            	        	j--;
				            	       }
				            	        
			            	       }
			            	       System.out.println("Output Files merged");
			            	       j=execCount-1;
			            	       while(j>=1) {
			            	    	   File filedel=new File("c:\\\\CompliantFSM\\\\Inputsmv\\\\outputS"+j+".txt");
			            	    	   filedel.delete();
			            	    	   j--;
			            	       }
			            	       System.out.println("Extra Output Deleted..");
			            	       textArea3.repaint();
			            	       JOptionPane.showMessageDialog(frame1, "Validation Done....");
			            	       FileReader read=new FileReader("c://CompliantFSM//Inputsmv//output.txt");
			            	         BufferedReader br=new BufferedReader(read);
			            	        	textArea3.read(br,null);
			            	        	br.close();
			            	        	textArea3.requestFocus();
			            	         }
			            	         catch(Exception es){
			            	         	
			            	         	
			            	         }
			            	     
			            	     
			            	      } catch (Exception ex) {
			            	         ex.printStackTrace();
			            	      }
			            	   
			            	
			            	
			            
			        }  
			        });
			        validate_button2.addActionListener(new ActionListener(){  
			            public void actionPerformed(ActionEvent e){ 
			            	try {
			            		try {
			            			
			            			int i=1;
			            			FileReader fexec=new FileReader("c:\\\\CompliantFSM\\\\execCount.txt");
			            			String tp="";
			            			int k;
			            			char c;
			            			while((k=fexec.read())!=-1)
			                    	{
			                    		
			                    		c=(char)k;
			            
			                    			if(k>=48 && k<=57)
			                    				tp=tp.concat(Character.toString(c));
			                    	}
			            			fexec.close();
			                    		
			                    		execCount=Integer.valueOf(tp);
			                    		i=1;
			                    		System.out.println("The exec count in Nusmv"+execCount);
			                    		while(i<execCount)
			                    		{
			                    			
			                    		Runtime.getRuntime().exec("cmd /k cd C://CompliantFSM/NuSMV/bin && NuSMV -source exec"+i+".txt"); 
			                           System.out.println("NuSMV2 Executed");
			                             i++;
			                    		}
			            			
			            			   File file=new File("c://CompliantFSM//Inputsmv//output.txt");
			            	    	   file.delete();
			            	       int j=execCount-1;
			               		FileReader f1=new FileReader("c://CompliantFSM//type.txt");
			                	 i=f1.read();
			                		 char typec=(char)i;
			                		 if(typec=='A') {
			            	       while(j>=1)
			            	       {
			            	        f1=new FileReader("C:\\CompliantFSM\\Inputsmv\\output"+j+".txt");
			            	        	BufferedWriter temp=new BufferedWriter(new FileWriter("c://CompliantFSM//Inputsmv//output.txt",true));
			            	        	 
			            	        	while((i=f1.read())!=-1)
			            	        	{
			            	        		c=(char)i;
			            	        		if(c!='!')
			            	        		temp.write(c);
			            	        	}
			            	        	f1.close();
			            	        	temp.close();
			            	        	j--;
			            	       }
			                	}
			                		 else if(typec=='E') {
			                			 while(j>=1)
					            	       {
					            	        	 f1=new FileReader("C:\\CompliantFSM\\Inputsmv\\output"+j+".txt");
					            	        	BufferedWriter temp=new BufferedWriter(new FileWriter("c://CompliantFSM//Inputsmv//output.txt",true));
					            	        	 
					            	        	while((i=f1.read())!=-1)
					            	        	{
					            	        		c=(char)i;
					            	        		if(c=='!') {
					            	        			char c1=c;
					            	        			i=f1.read();
					            	        			c=(char)i;
					            	        			if(c!='=') {
					            	        				temp.write(c1);
					            	        				temp.write(c);
					            	        			}
					            	        			else
					            	        				temp.write(c);
					            	        		}
					            	        		else if(c=='i') {
					            	        			char c2=c;
					            	        			i=f1.read();
					            	        			c=(char)i;
					            	        			if(c=='s') {
					            	        				temp.write(c2);
					            	        				temp.write(c);
					            	        				break;
					            	        			}
					            	        			else {
					            	        				temp.write(c2);
					            	        				temp.write(c);
					            	        			}
					            	        		}
					            	        		else
					            	        			temp.write(c);
					            	        		
					            	        	}
					            	        	f1.close();
					            	        	File fl=new File("C:\\CompliantFSM\\Inputsmv\\output"+j+".txt");
					            	        	fl.delete();
					            	        	temp.write("true");
					            	        	temp.newLine();
					            	        	temp.close();
					            	        	j--;
					            	       }
					            	    
			                		 }
			            	       j=execCount-1;
			            	       while(j>=1) {
			            	    	   File filedel=new File("c:\\\\CompliantFSM\\\\Inputsmv\\\\output"+j+".txt");
			            	    	   filedel.delete();
			            	    	   j--;
			            	       }
			            	       textArea3.repaint();
			            	       JOptionPane.showMessageDialog(frame1, "Validation Done....");
			            	       FileReader read=new FileReader("c://CompliantFSM//Inputsmv//output.txt");
			            	         BufferedReader br=new BufferedReader(read);
			            	        	textArea3.read(br,null);
			            	        	br.close();
			            	        	textArea3.requestFocus();
			            	         }
			            	         catch(Exception es){
			            	         	
			            	         	
			            	         }
			            	     
			            	     
			            	      } catch (Exception ex) {
			            	         ex.printStackTrace();
			            	      } 
			        }  
			        });
			        
				     frame1.setVisible(true);
				   
				     int jpk=0;
			     
			

					
		}

	private static void ChooseButtonActionPerformed(ActionEvent e) {
	    JFileChooser fileChooser = new JFileChooser("c:\\\\CompliantFSM\\\\input_model");
	    int returnValue = fileChooser.showOpenDialog(null);
	    if (returnValue == JFileChooser.APPROVE_OPTION)
	    {
	        File selectedFile = fileChooser.getSelectedFile();
	        System.out.println(selectedFile.getName());
	        String name=selectedFile.getAbsolutePath();
	        selected_file=name;
	        try {
	        	/* InputStream in = new FileInputStream(new File(name));
	             OutputStream out = new FileOutputStream(new File("C:\\Users\\Mandira Roy\\dsl\\novadsl1\\input1.ndsl"));
	             byte[] buf = new byte[1024];
	             int len;
	             
	             while ((len = in.read(buf)) > 0) {
	                out.write(buf, 0, len);
	             }
	             in.close();
	             out.close();*/
	        
	        	   // name="";
	     //   name="C:\\Users\\Mandira Roy\\dsln\\novadsl1\\input1.ndsl";
	       	FileReader read=new FileReader(selected_file);
	       	BufferedReader br=new BufferedReader(read);
	       	textAreaF.read(br,null);
	       	br.close();
	       	textAreaF.requestFocus();
	        }
	        catch(Exception es){
	        	
	        	
	        }
	    
	       /* try {
	           // Thread.sleep(1000);
	        } catch (InterruptedException ie)
	        {
	            System.out.println("Scanning...");
	        }*/
	       // JOptionPane.showMessageDialog(frame1, "Wait for Constraint checking");
	        
	    }
	    get_ActorGoalList();
		delete_files2();
	}
	private static void ChooseButtonActionPerformednew(ActionEvent e) {
	  try {
		  System.out.println("heyy");
	       	FileReader read=new FileReader("c:\\\\CompliantFSM\\\\temp_input.ndsl");
	       	BufferedReader br=new BufferedReader(read);
	       	textAreaF.read(br,null);
	       	br.close();
	       	textAreaF.requestFocus();
	        }
	        catch(Exception es){
	        	
	        	System.out.println("hiee");
	        }
	 
	    
	      
	}
	public static void get_ActorGoalList() {
		System.out.println("Function called for FSM");
		System.out.println("The selected file is"+selected_file);
		try
		{
			Injector inj = new ManDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			//com.google.inject.Injector inj =  new NovaDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			XtextResourceSet resourceSet = inj.getInstance(XtextResourceSet.class);
			resourceSet.addLoadOption(XtextResource.OPTION_RESOLVE_ALL, Boolean.TRUE);
			Resource xtextResource=resourceSet.getResource(URI.createFileURI(selected_file), true);
			EcoreUtil.resolveAll(xtextResource);
			Resource xmiResource=resourceSet.createResource(URI.createFileURI("c:\\\\CompliantFSM\\\\input_model/goal.xmi"));
			xmiResource.getContents().add(xtextResource.getContents().get(0));
			xmiResource.save(null);
			Launcher launcher = new Launcher();
			launcher.runAcceleo("c:\\\\CompliantFSM\\\\input_model/metamodels/NovaDsl.ecore", "NovaDsl", "c:\\\\CompliantFSM\\\\input_model/goal.xmi",
							"src/AcceleoMTLRunner/main/GenerateList.mtl", "c:\\\\CompliantFSM\\\\input_model/gen/");
			
				
		}
		catch(Exception e )
		{
			System.out.println(e.toString());
		}	
	}
	public static void create_output() {
		System.out.println("Function called for FSM");
		System.out.println("The selected file is"+selected_file);
		try
		{
			Injector inj = new ManDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			//com.google.inject.Injector inj =  new NovaDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			XtextResourceSet resourceSet = inj.getInstance(XtextResourceSet.class);
			resourceSet.addLoadOption(XtextResource.OPTION_RESOLVE_ALL, Boolean.TRUE);
			Resource xtextResource=resourceSet.getResource(URI.createFileURI(selected_file), true);
			EcoreUtil.resolveAll(xtextResource);
			Resource xmiResource=resourceSet.createResource(URI.createFileURI("c:\\\\CompliantFSM\\\\input_model/goal.xmi"));
			xmiResource.getContents().add(xtextResource.getContents().get(0));
			xmiResource.save(null);
			Launcher launcher = new Launcher();
			launcher.runAcceleo("c:\\\\CompliantFSM\\\\input_model/metamodels/NovaDsl.ecore", "NovaDsl", "c:\\\\CompliantFSM\\\\input_model/goal.xmi",
							"src/AcceleoMTLRunner/main/SIA.mtl", "c:\\\\CompliantFSM\\\\input_model/gen/");
			
				
		}
		catch(Exception e )
		{
			System.out.println(e.toString());
		}	
		try
		{
			Injector inj = new ManDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			//com.google.inject.Injector inj =  new NovaDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			XtextResourceSet resourceSet = inj.getInstance(XtextResourceSet.class);
			resourceSet.addLoadOption(XtextResource.OPTION_RESOLVE_ALL, Boolean.TRUE);
			Resource xtextResource=resourceSet.getResource(URI.createFileURI(selected_file), true);
			EcoreUtil.resolveAll(xtextResource);
			Resource xmiResource=resourceSet.createResource(URI.createFileURI("c:\\\\CompliantFSM\\\\input_model/goal.xmi"));
			xmiResource.getContents().add(xtextResource.getContents().get(0));
			xmiResource.save(null);
			Launcher launcher = new Launcher();
			launcher.runAcceleo("c:\\\\CompliantFSM\\\\input_model/metamodels/NovaDsl.ecore", "NovaDsl", "c:\\\\CompliantFSM\\\\input_model/goal.xmi",
							"src/AcceleoMTLRunner/main/mSIA.mtl", "c:\\\\CompliantFSM\\\\input_model/gen/");
			
				
		}
		catch(Exception e )
		{
			System.out.println(e.toString());
		}	
		set_metrics();
		activate_buttons();
	}
	public static void set_metrics() {
		try {
			File f=new File("c:\\\\CompliantFSM\\\\existential.txt");
			if(f.exists()) {
        	FileReader read=new FileReader("c:\\\\CompliantFSM\\\\existential.txt");
       
        	BufferedReader br=new BufferedReader(read);
        	textCTL.setColumns(100);
        	textCTL.read(br,null);
        	
        	br.close();
        	textCTL.requestFocus();
			}
        	FileReader f1=new FileReader("c:\\\\CompliantFSM\\\\SIAmetric.txt");
        	int i;
        	char c;
       int t1=0,t2=0,p1=0,p2=0;
        	while((i=f1.read())!=-1)
        	{
        		String temp="";
        		c=(char)i;
    			temp=temp.concat(Character.toString(c));
        		while((i=f1.read())!=10)
        		{
        			c=(char)i;
        			if(i>=48 && i<=57)
        				temp=temp.concat(Character.toString(c));
        		}
        		
        		texttransitions.setText(temp);
        		System.out.println("temp is"+temp);
        		System.out.println("length is"+temp.length());
        		t1=Integer.valueOf(temp);
        		int k=0;
        		int num=0;
        	/*	while(k<temp.length()) {
        			num=num*10;
        			num+=temp.charAt(i)-'0';
        			System.out.println("Int is"+num);
        			k++;
        		}*/
        		System.out.println("Int is"+num);
        		//t1=temp;
        		temp="";
        		while((i=f1.read())!=10)
        		{
        			c=(char)i;
        			if(i>=48 && i<=57)
        				temp=temp.concat(Character.toString(c));
        		}
        		textpaths.setText(temp);
        		p1=Integer.valueOf(temp);
        		//p1=temp;
        		temp="";
        		while((i=f1.read())!=-1)
        		{
        			c=(char)i;
        			temp=temp.concat(Character.toString(c));
        		}
        		textTime.setText(temp);
        	}
        	 f1=new FileReader("c:\\\\CompliantFSM\\\\mSIAmetric.txt");
    
        	while((i=f1.read())!=-1)
        	{
        		String temp="";
        		c=(char)i;
    			temp=temp.concat(Character.toString(c));
        		while((i=f1.read())!=10)
        		{
        			c=(char)i;
        			if(i>=48 && i<=57)
        				temp=temp.concat(Character.toString(c));
        		}
        		texttransitions2.setText(temp);
        		t2=Integer.valueOf(temp);
        		//t2=temp;
        		temp="";
        		while((i=f1.read())!=10)
        		{
        			c=(char)i;
        			if(i>=48 && i<=57)
        				temp=temp.concat(Character.toString(c));
        		}
        		textpaths2.setText(temp);
        		p2=Integer.valueOf(temp);
        		//p2=temp;
        		temp="";
        		while((i=f1.read())!=-1)
        		{
        			c=(char)i;
        			temp=temp.concat(Character.toString(c));
        		}
        		textTime2.setText(temp);
        	}
        	float reduce1=((float)(t1-t2))/(float)t1*100;
			float reduce2=((float)(p1-p2))/(float)p1*100;
			String s1=Float.toString(reduce1);
			String s2=Float.toString(reduce2);
			reduceTransition.setText(s1);
			reducePaths.setText(s2);
			f1=new FileReader("c:\\\\CompliantFSM\\\\nodecount.txt");
			while((i=f1.read())!=-1) {
				String temp="";
				c=(char)i;
				if(i>=48 && i<=57)
					temp=temp.concat(Character.toString(c));
				while((i=f1.read())!=10) {
					c=(char)i;
					if(i>=48 && i<=57)
						temp=temp.concat(Character.toString(c));
				}
				nodes.setText(temp);
				temp="";
				while((i=f1.read())!=10) {
					while(i!=32) {
					c=(char)i;
					if(i>=48 && i<=57)
						temp=temp.concat(Character.toString(c));
						i=f1.read();
					}
					andnum.setText(temp);
					i=f1.read();
					temp="";
					while(i!=10) {
						c=(char)i;
						if(i>=48 && i<=57)
							temp=temp.concat(Character.toString(c));
							i=f1.read();
						}
					andchild.setText(temp);
					break;
				}
				temp="";
				while((i=f1.read())!=10) {
					while(i!=32) {
					c=(char)i;
					if(i>=48 && i<=57)
						temp=temp.concat(Character.toString(c));
						i=f1.read();
					}
					ornum.setText(temp);
					i=f1.read();
					temp="";
					while(i!=10) {
						c=(char)i;
						if(i>=48 && i<=57)
							temp=temp.concat(Character.toString(c));
							i=f1.read();
						}
					orchild.setText(temp);
					break;
				}
				break;
				
			}
        	}
        	  catch(Exception es){
        		  JOptionPane.showMessageDialog(frame1, "Wait for FSM generation...");
  	        	
  	        }
		
	}
	public static void activate_buttons() {
		checkNuSMV_button.setEnabled(true);
		checkNuSMV_button2.setEnabled(true);
		validate_button.setEnabled(true);
		validate_button2.setEnabled(true);
		save_button.setEnabled(true);
		output_file_button.setEnabled(true);
		output_file_button2.setEnabled(true);
		
	}
	public static void initialize() {
		deleted="";
		selected_file="";
	}
	public static void start_operation() {
		frameFirst=new JFrame("Set Input");
		initialize();
		delete_files();
		create_firstFrame();
	}


	public static void main(String[] args) {
		System.out.println("Hello");
		//start_operation();

		/*try
		{
			Injector inj = new ManDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			//com.google.inject.Injector inj =  new NovaDslStandaloneSetup().createInjectorAndDoEMFRegistration();
			XtextResourceSet resourceSet = inj.getInstance(XtextResourceSet.class);
			resourceSet.addLoadOption(XtextResource.OPTION_RESOLVE_ALL, Boolean.TRUE);
			Resource xtextResource=resourceSet.getResource(URI.createFileURI("F:/input_model/test.ndsl"), true);
			EcoreUtil.resolveAll(xtextResource);
			Resource xmiResource=resourceSet.createResource(URI.createFileURI("F:/input_model/goal.xmi"));
			xmiResource.getContents().add(xtextResource.getContents().get(0));
			xmiResource.save(null);
			Launcher launcher = new Launcher();
			launcher.runAcceleo("F:/input_model/metamodels/NovaDsl.ecore", "NovaDsl", "F:/input_model/goal.xmi",
							"src/AcceleoMTLRunner/main/Maingenerate.mtl", "F:/input_model/gen/");
			
				
		}
		catch(Exception e )
		{
			System.out.println(e.toString());
		}*/

	}

}
